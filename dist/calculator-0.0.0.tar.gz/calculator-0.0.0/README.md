# SI-UKKW-SIWP2005-OOP 

### Scientific Calculator Case Study

building a simple scientific calculator pip package that supports basic and scientific operations.
